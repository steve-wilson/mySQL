drop table if exists test.movies;
drop view if exists test.movies;
set @start = sysdate(6)+0;
load data local infile '/Users/blubben/Desktop/Datasets/Movies/movies_1.csv' into table test.movies schema_merge dummy lines terminated by "\n";
load data local infile '/Users/blubben/Desktop/Datasets/Movies/movies_2.txt' into table test.movies schema_merge dummy fields terminated by "\t" lines terminated by "\n";
load data local infile '/Users/blubben/Desktop/Datasets/Movies/movies_3.txt' into table test.movies schema_merge dummy fields terminated by ";" lines terminated by "\n";
load data local infile '/Users/blubben/Desktop/Datasets/Movies/movies_4.csv' into table test.movies schema_merge dummy lines terminated by "\n";
select (sysdate(6)+0)-@start;
